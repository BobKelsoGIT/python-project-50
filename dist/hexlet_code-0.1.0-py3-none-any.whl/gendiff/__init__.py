from gendiff.gendiff import generate_diff
from gendiff.parser import get_extension, get_data

__all__ = ('generate_diff',
           'get_extension',
           'get_data')

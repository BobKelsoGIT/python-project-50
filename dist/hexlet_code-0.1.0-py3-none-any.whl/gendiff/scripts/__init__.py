from gendiff.scripts.gendiff import generate_diff
from gendiff.scripts.cli import parse_args

__all__ = (
    'parse_args',
    'generate_diff',
)

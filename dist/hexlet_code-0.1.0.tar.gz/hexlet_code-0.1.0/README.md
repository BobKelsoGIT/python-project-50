[![Actions Status](https://github.com/BobKelsoGIT/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/BobKelsoGIT/python-project-50/actions)
[![gendiff](https://github.com/BobKelsoGIT/python-project-50/actions/workflows/gendiff.yml/badge.svg)](https://github.com/BobKelsoGIT/python-project-50/actions/workflows/gendiff.yml)
[![Maintainability](https://api.codeclimate.com/v1/badges/b42057f8d3446129fd33/maintainability)](https://codeclimate.com/github/BobKelsoGIT/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/b42057f8d3446129fd33/test_coverage)](https://codeclimate.com/github/BobKelsoGIT/python-project-50/test_coverage)

<h3 align="center">Example with JSON files:</h3>

[![asciicast](https://asciinema.org/a/8TTwzBSBwyo1JE47AvmKo5KA3.svg)](https://asciinema.org/a/8TTwzBSBwyo1JE47AvmKo5KA3)

<h3 align="center">Example with YAML files:</h3>

[![asciicast](https://asciinema.org/a/aBTP8NyeSBrmb2sYqaNfydc15.svg)](https://asciinema.org/a/aBTP8NyeSBrmb2sYqaNfydc15)
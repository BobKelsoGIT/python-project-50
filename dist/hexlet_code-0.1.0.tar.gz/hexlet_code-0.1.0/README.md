### Hexlet tests and linter status:
[![Actions Status](https://github.com/BobKelsoGIT/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/BobKelsoGIT/python-project-50/actions)

[![asciicast](https://asciinema.org/a/8TTwzBSBwyo1JE47AvmKo5KA3.svg)](https://asciinema.org/a/8TTwzBSBwyo1JE47AvmKo5KA3)
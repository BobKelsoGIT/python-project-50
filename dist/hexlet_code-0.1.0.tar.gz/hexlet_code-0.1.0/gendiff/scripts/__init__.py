from gendiff.cli import parse_args

__all__ = (
    'parse_args',
)
